﻿#region 文件信息

/*----------------------------------------------------------------
//
// 文件名称：
// 文件功能描述：
// 设计要求：
//
// 文 件 名：    MainViewModel
// 创建者：      杨程
// 创建日期：	    2023/2/20 21:05:39

//----------------------------------------------------------------*/

#endregion

namespace $safeprojectname$.ViewModels;

/// <summary>
///
/// </summary>
[VampirewalIoCRegister(ViewModelKeys.MainViewModel)]
public partial class MainViewModel : ViewModelBase
{
    /// <summary>
    ///
    /// </summary>
    public MainViewModel()
    {
        //构造函数
        var AppBaseInfo = VampirewalCoreContext.GetInstance().GetOptions<AppBaseOptions>();//通过这种方式去获取到配置

        Title = AppBaseInfo.AppChineseName;
    }
}