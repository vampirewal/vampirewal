﻿#region 文件信息

/*----------------------------------------------------------------
//
// 文件名称：
// 文件功能描述：
// 设计要求：
//
// 文 件 名：    ViewKeys
// 创建者：      杨程
// 创建日期：	    2023/2/20 21:04:28

//----------------------------------------------------------------*/

#endregion

namespace $safeprojectname$.Common;

/// <summary>
/// View窗体的Token
/// </summary>
public partial class ViewKeys
{
    public const string MainView = "$safeprojectname$.Views.MainView";
}