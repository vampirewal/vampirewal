﻿#region 文件信息

/*----------------------------------------------------------------
//
// 文件名称：
// 文件功能描述：
// 设计要求：
//
// 文 件 名：    ViewModelKeys
// 创建者：      杨程
// 创建日期：	    2023/2/20 21:05:11

//----------------------------------------------------------------*/

#endregion

namespace $safeprojectname$.Common;

/// <summary>
/// ViewModel的注册Token
/// </summary>
public partial class ViewModelKeys
{
    public const string MainViewModel = "$safeprojectname$.ViewModels.MainViewModel";
}