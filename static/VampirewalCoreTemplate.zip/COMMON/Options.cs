﻿#region 文件信息

/*----------------------------------------------------------------
//
// 文件名称：
// 文件功能描述：
// 设计要求：
//
// 文 件 名：    Options
// 创建者：      杨程
// 创建日期：	    2023/2/20 21:38:26

//----------------------------------------------------------------*/

#endregion

namespace $safeprojectname$.Common;

/// <summary>
/// 运行环境配置
/// </summary>
public class EnvironmentOptions : IOptions
{
    /// <summary>
    /// 运行环境 ，可填Pre，Dev或Online等，自行定义
    /// </summary>
    public string Environment { get; set; }
}