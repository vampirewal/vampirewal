﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace $safeprojectname$.Views;

/// <summary>
/// MainView.xaml 的交互逻辑
/// </summary>
[VampirewalIoCRegister(ViewKeys.MainView)]//将窗体以这个Token注册进IServiceCollection
public partial class MainView : MainWindowBase
{
    public MainView()
    {
        InitializeComponent();
    }

    public override string ViewModelKey => ViewModelKeys.MainViewModel;//当前窗体的ViewModel对应的Token
}
