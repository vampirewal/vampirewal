﻿global using System;
global using System.Collections.Generic;
global using System.Configuration;
global using System.Data;
global using System.Linq;
global using System.Threading.Tasks;
global using System.Windows;
global using Vampirewal.Core.Components;
global using Vampirewal.Core.Extensions;
global using $safeprojectname$.DataAccess;
global using Microsoft.Extensions.DependencyInjection;
global using Vampirewal.Core.Interface;
global using Vampirewal.Core.SimpleMVVM;
global using Vampirewal.Core.Attributes;
global using Vampirewal.Core.WpfTheme.WindowStyle;
global using $safeprojectname$.Common;
global using $safeprojectname$.Views;
global using SqlSugar;
global using Vampirewal.Core;
global using Vampirewal.Core.ConfigOptions;

namespace $safeprojectname$;

/// <summary>
/// Interaction logic for App.xaml
/// </summary>
public partial class App : VampirewalApplication
{
    protected override Type BootStartUp()
    {
        return typeof(BootStatup);
    }

}
