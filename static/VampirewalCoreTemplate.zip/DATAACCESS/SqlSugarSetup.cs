﻿#region 文件信息

/*----------------------------------------------------------------
//
// 文件名称：
// 文件功能描述：
// 设计要求：
//
// 文 件 名：    SqlSugarSetup
// 创建者：      杨程
// 创建日期：	    2023/2/20 19:18:59

//----------------------------------------------------------------*/

#endregion

namespace $safeprojectname$.DataAccess;

/// <summary>
///
/// </summary>
public partial class SqlSugarSetup : VampirewalCoreSqlSugarSetup
{
    public override void CodeFirst()
    {
    }

    public override void OnLogExecuting(string sql, SugarParameter[] para)
    {
        base.OnLogExecuting(sql, para);
    }

    public override void DataExecuted(object value, DataAfterModel entity)
    {
    }

    public override void DataExecuting(object OldValue, DataFilterModel entityInfo)
    {
        base.DataExecuting(OldValue, entityInfo);
    }

    public override ConnectionConfig GetDbConnectionConfig(string DbName, string ConnStr, DBTypeEnum? dbType)
    {
        return base.GetDbConnectionConfig(DbName, ConnStr, dbType);
    }

    public override string GetSqlExecuteTimeMoreOnceSecond()
    {
        return base.GetSqlExecuteTimeMoreOnceSecond();
    }

    public override void OnError(SqlSugarException exp)
    {
    }

    public override KeyValuePair<string, SugarParameter[]> OnExecutingChangeSql(string sql, SugarParameter[] pars)
    {
        return base.OnExecutingChangeSql(sql, pars);
    }

    public override void OnLogExecuted(string sql, SugarParameter[] para)
    {
    }
}