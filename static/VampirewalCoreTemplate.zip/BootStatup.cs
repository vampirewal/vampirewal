﻿#region 文件信息

/*----------------------------------------------------------------
//
// 文件名称：
// 文件功能描述：
// 设计要求：
//
// 文 件 名：    VampirewalCoreBootStatup
// 创建者：      杨程
// 创建日期：	    2023/2/20 19:17:50

//----------------------------------------------------------------*/

#endregion

namespace $safeprojectname$;

/// <summary>
///
/// </summary>
public partial class BootStatup : VampirewalBootStartUp
{
    protected override string FirstViewKey => ViewKeys.MainView;

    protected override void RegisterService(IServiceCollection services)
    {
        //将系统配置模块注册进IServiceCollection
        services.AddVampirewalCoreConfig($"{AppDomain.CurrentDomain.BaseDirectory}AppConfig.json", options =>
        {
            options.RegisterOptions<EnvironmentOptions>();//此处在项目中找到Common的Options内查看各项配置项
        });
        services.AddSingleton<IVampirewalCoreDialogMessage, VampirewalCoreDialogService>();//注册窗体弹窗服务
        services.UseVampirewalCoreSqlSugar<SqlSugarSetup>();//注册Sqlsugar并配置SqlSugar启动项
        services.AddScoped(typeof(SqlSugarRepository<>));//注册SqlSugar仓储
        services.AddSingleton<IVampirewalCoreLogService, VampirewalCoreLogService>();//注册框架自带的简单日志服务
    }
}